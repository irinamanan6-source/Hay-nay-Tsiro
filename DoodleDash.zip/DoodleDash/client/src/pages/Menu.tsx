import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import RestaurantHeader from '@/components/RestaurantHeader';
import CategoryNav from '@/components/CategoryNav';
import HeroSection from '@/components/HeroSection';
import MenuSection from '@/components/MenuSection';
import CartDrawer from '@/components/CartDrawer';
import type { MenuItem, CartItem } from '@shared/schema';

// Fetch menu items from API
const fetchMenuItems = async (): Promise<MenuItem[]> => {
  const response = await fetch('/api/menu-items');
  if (!response.ok) {
    throw new Error('Failed to fetch menu items');
  }
  return response.json();
};

// Submit order to API
const submitOrder = async (orderData: { 
  customerName?: string; 
  customerPhone?: string;
  items: { menuItemId: string; name: string; price: number; quantity: number; }[];
  paymentMethod: string;
}) => {
  const response = await fetch('/api/orders', {
    method: 'POST',
    body: JSON.stringify(orderData),
    headers: {
      'Content-Type': 'application/json',
    },
  });
  
  if (!response.ok) {
    throw new Error('Failed to submit order');
  }
  
  return response.json();
};

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('petit-dejeuner');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { toast } = useToast();

  const categories = ['petit-dejeuner', 'plat-riz', 'beignet', 'boisson-chaud'];
  
  // Fetch menu items from API
  const { data: menuItems = [], isLoading, error } = useQuery({
    queryKey: ['menu-items'],
    queryFn: fetchMenuItems
  });

  // Order submission mutation
  const orderMutation = useMutation({
    mutationFn: submitOrder,
    onSuccess: (order: any) => {
      toast({
        title: "Commande confirmée !",
        description: `Votre commande #${order.id.slice(0, 8)} a été soumise avec succès.`,
      });
      setCartItems([]);
      setIsCartOpen(false);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Erreur de commande",
        description: "Une erreur s'est produite lors de la soumission de votre commande.",
      });
    }
  });
  
  const categoryDisplayNames: { [key: string]: string } = {
    "petit-dejeuner": "Petit Déjeuner",
    "plat-riz": "Plat de Riz Malagasy", 
    "beignet": "Beignet Malagasy",
    "boisson-chaud": "Boisson Chaud"
  };

  const filteredItems = useMemo(() => {
    return menuItems.filter(item => item.category === activeCategory);
  }, [menuItems, activeCategory]);

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleQuantityChange = (itemId: string, quantity: number) => {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;

    setCartItems(prev => {
      if (quantity === 0) {
        return prev.filter(cartItem => cartItem.id !== itemId);
      }

      const existingItem = prev.find(cartItem => cartItem.id === itemId);
      if (existingItem) {
        return prev.map(cartItem =>
          cartItem.id === itemId ? { ...cartItem, quantity } : cartItem
        );
      } else {
        return [...prev, { id: itemId, name: item.name, price: item.price, quantity }];
      }
    });
  };

  const handleCartUpdate = (itemId: string, quantity: number) => {
    handleQuantityChange(itemId, quantity);
  };

  const handleConfirmOrder = (paymentMethod: string) => {
    if (cartItems.length === 0) return;
    
    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Convert cart items to order format
    const orderItems = cartItems.map(item => ({
      menuItemId: item.id,
      name: item.name,
      price: item.price,
      quantity: item.quantity
    }));

    // Submit order
    orderMutation.mutate({
      items: orderItems,
      paymentMethod
    });
  };

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-destructive mb-2">Erreur de chargement</h2>
          <p className="text-muted-foreground">Impossible de charger le menu. Veuillez réessayer.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <RestaurantHeader 
        cartItemCount={cartItemCount}
        onCartClick={() => setIsCartOpen(true)}
      />
      
      <CategoryNav
        categories={categories}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />
      
      <HeroSection />
      
      {isLoading ? (
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-muted-foreground">Chargement du menu...</p>
          </div>
        </div>
      ) : (
        <MenuSection
          title={categoryDisplayNames[activeCategory]}
          items={filteredItems}
          cartItems={cartItems}
          onQuantityChange={handleQuantityChange}
        />
      )}
      
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleCartUpdate}
        onConfirmOrder={handleConfirmOrder}
        isLoading={orderMutation.isPending}
      />
    </div>
  );
}