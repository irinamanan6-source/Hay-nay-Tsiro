import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface RestaurantHeaderProps {
  cartItemCount: number;
  onCartClick: () => void;
}

export default function RestaurantHeader({ cartItemCount, onCartClick }: RestaurantHeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-restaurant-name">
            Hay'nay Tsiro
          </h1>
          <p className="text-sm opacity-90" data-testid="text-restaurant-tagline">
            Spécialité Malagasy
          </p>
        </div>
        
        <Button 
          variant="outline" 
          size="icon" 
          onClick={onCartClick}
          className="relative bg-primary-foreground/10 border-primary-foreground/20 hover:bg-primary-foreground/20"
          data-testid="button-cart"
        >
          <ShoppingCart className="h-5 w-5" />
          {cartItemCount > 0 && (
            <Badge 
              className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-accent text-xs font-bold text-accent-foreground"
              data-testid="badge-cart-count"
            >
              {cartItemCount}
            </Badge>
          )}
        </Button>
      </div>
    </header>
  );
}