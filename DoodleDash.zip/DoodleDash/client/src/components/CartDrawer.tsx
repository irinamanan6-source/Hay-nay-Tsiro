import { useState } from 'react';
import { X, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { CartItem } from '@shared/schema';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onConfirmOrder: (paymentMethod: string) => void;
  isLoading?: boolean;
}

export default function CartDrawer({ isOpen, onClose, items, onUpdateQuantity, onConfirmOrder, isLoading = false }: CartDrawerProps) {
  const [paymentMethod, setPaymentMethod] = useState<string>('espèces');
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  const handleConfirm = () => {
    if (!paymentMethod) {
      return; // Don't submit if no payment method selected
    }
    onConfirmOrder(paymentMethod);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={onClose}>
      <div 
        className="fixed right-0 top-0 h-full w-full max-w-md bg-background shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="h-full rounded-none border-0">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2" data-testid="text-cart-title">
                <ShoppingBag className="h-5 w-5" />
                Votre Commande
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-cart">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="flex-1 p-4 overflow-y-auto">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                <ShoppingBag className="h-12 w-12 mb-2 opacity-50" />
                <p data-testid="text-empty-cart">Votre panier est vide</p>
              </div>
            ) : (
              <div className="space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm" data-testid={`text-cart-item-${item.id}`}>
                        {item.name}
                      </h4>
                      <p className="text-accent font-semibold text-sm" data-testid={`text-cart-price-${item.id}`}>
                        {item.quantity} x {item.price.toLocaleString()} Ar
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        data-testid={`button-cart-decrease-${item.id}`}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center text-sm font-semibold" data-testid={`text-cart-quantity-${item.id}`}>
                        {item.quantity}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        data-testid={`button-cart-increase-${item.id}`}
                      >
                        +
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
          
          {items.length > 0 && (
            <div className="border-t p-4 space-y-4">
              <div className="flex justify-between items-center text-lg font-bold">
                <span>Total:</span>
                <span className="text-accent" data-testid="text-cart-total">
                  {total.toLocaleString()} Ar
                </span>
              </div>
              
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger data-testid="select-payment-method">
                  <SelectValue placeholder="Méthode de paiement" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="espèces">Espèces</SelectItem>
                  <SelectItem value="mobile-money">Mobile Money</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                className="w-full" 
                size="lg"
                onClick={handleConfirm}
                disabled={isLoading || !paymentMethod}
                data-testid="button-confirm-order"
              >
                {isLoading ? 'Traitement en cours...' : 'Confirmer la commande'}
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}