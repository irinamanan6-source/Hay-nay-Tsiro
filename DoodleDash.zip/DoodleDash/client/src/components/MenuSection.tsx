import MenuItemCard from './MenuItemCard';
import type { MenuItem, CartItem } from '@shared/schema';

interface MenuSectionProps {
  title: string;
  items: MenuItem[];
  cartItems: CartItem[];
  onQuantityChange: (itemId: string, quantity: number) => void;
}

export default function MenuSection({ title, items, cartItems, onQuantityChange }: MenuSectionProps) {
  const getItemQuantity = (itemId: string) => {
    return cartItems.find(item => item.id === itemId)?.quantity || 0;
  };

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6 text-foreground border-b-2 border-accent pb-2" data-testid={`text-section-title-${title}`}>
          {title}
        </h2>
        <div className="grid gap-4">
          {items.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              quantity={getItemQuantity(item.id)}
              onQuantityChange={onQuantityChange}
            />
          ))}
        </div>
      </div>
    </section>
  );
}