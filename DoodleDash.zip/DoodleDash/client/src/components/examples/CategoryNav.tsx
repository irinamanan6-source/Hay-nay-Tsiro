import CategoryNav from '../CategoryNav';

export default function CategoryNavExample() {
  return (
    <CategoryNav 
      categories={["petit-dejeuner", "plat-riz", "beignet", "boisson-chaud"]}
      activeCategory="petit-dejeuner"
      onCategoryChange={(category) => console.log('Category changed to:', category)}
    />
  );
}