import RestaurantHeader from '../RestaurantHeader';

export default function RestaurantHeaderExample() {
  return (
    <RestaurantHeader 
      cartItemCount={3} 
      onCartClick={() => console.log('Cart clicked')} 
    />
  );
}