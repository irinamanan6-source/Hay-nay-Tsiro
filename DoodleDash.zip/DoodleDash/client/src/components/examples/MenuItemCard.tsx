import MenuItemCard from '../MenuItemCard';

export default function MenuItemCardExample() {
  const sampleItem = {
    id: '1',
    name: 'Vary amin\'ny anana spéciale',
    description: 'Riz aux légumes spécialité maison',
    price: 15000,
    category: 'petit-dejeuner',
    imageUrl: null,
    available: 1
  };

  return (
    <div className="max-w-md">
      <MenuItemCard 
        item={sampleItem}
        quantity={0}
        onQuantityChange={(id, qty) => console.log(`Item ${id} quantity changed to:`, qty)}
      />
    </div>
  );
}