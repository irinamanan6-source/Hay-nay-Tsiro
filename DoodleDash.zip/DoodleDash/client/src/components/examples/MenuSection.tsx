import MenuSection from '../MenuSection';

export default function MenuSectionExample() {
  const sampleItems = [
    {
      id: '1',
      name: 'Vary amin\'ny anana spéciale',
      description: 'Riz aux légumes spécialité maison',
      price: 15000,
      category: 'petit-dejeuner',
      imageUrl: null,
      available: 1
    },
    {
      id: '2',
      name: 'Spécialité mokary',
      description: 'Gâteau traditionnel malagasy',
      price: 5000,
      category: 'petit-dejeuner',
      imageUrl: null,
      available: 1
    }
  ];

  const cartItems = [
    { id: '1', name: 'Vary amin\'ny anana spéciale', price: 15000, quantity: 1 }
  ];

  return (
    <MenuSection
      title="Petit Déjeuner"
      items={sampleItems}
      cartItems={cartItems}
      onQuantityChange={(id, qty) => console.log(`Item ${id} quantity changed to:`, qty)}
    />
  );
}