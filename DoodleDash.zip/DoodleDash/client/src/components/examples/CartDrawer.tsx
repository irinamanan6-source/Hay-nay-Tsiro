import CartDrawer from '../CartDrawer';

export default function CartDrawerExample() {
  const sampleItems = [
    { id: '1', name: 'Vary amin\'ny anana spéciale', price: 15000, quantity: 2 },
    { id: '2', name: 'Café au lait', price: 2000, quantity: 1 }
  ];

  return (
    <CartDrawer
      isOpen={true}
      onClose={() => console.log('Cart closed')}
      items={sampleItems}
      onUpdateQuantity={(id, qty) => console.log(`Update ${id} to ${qty}`)}
      onConfirmOrder={(method) => console.log(`Order confirmed with ${method}`)}
    />
  );
}