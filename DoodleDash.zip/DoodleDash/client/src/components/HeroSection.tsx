import heroImage from '@assets/generated_images/Malagasy_food_hero_image_219be9d0.png';

export default function HeroSection() {
  return (
    <div className="relative h-64 md:h-80 overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-primary/70" />
      <div className="relative container mx-auto px-4 h-full flex items-center justify-center text-center">
        <div className="text-primary-foreground">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-hero-title">
            Saveurs Authentiques de Madagascar
          </h2>
          <p className="text-lg md:text-xl opacity-90 max-w-2xl" data-testid="text-hero-description">
            Découvrez nos spécialités malagasy préparées avec amour selon les recettes traditionnelles
          </p>
        </div>
      </div>
    </div>
  );
}