import { useState, useEffect } from 'react';
import { Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import type { MenuItem } from '@shared/schema';

interface MenuItemCardProps {
  item: MenuItem;
  quantity: number;
  onQuantityChange: (itemId: string, quantity: number) => void;
}

export default function MenuItemCard({ item, quantity, onQuantityChange }: MenuItemCardProps) {
  const [localQuantity, setLocalQuantity] = useState(quantity);
  
  // Sync local state when quantity prop changes (e.g., from CartDrawer updates)
  useEffect(() => {
    setLocalQuantity(quantity);
  }, [quantity]);

  const handleIncrement = () => {
    const newQuantity = localQuantity + 1;
    setLocalQuantity(newQuantity);
    onQuantityChange(item.id, newQuantity);
  };

  const handleDecrement = () => {
    const newQuantity = Math.max(0, localQuantity - 1);
    setLocalQuantity(newQuantity);
    onQuantityChange(item.id, newQuantity);
  };

  return (
    <Card className="hover-elevate transition-all duration-200">
      <CardContent className="p-4">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <h3 className="font-semibold text-foreground mb-1" data-testid={`text-item-name-${item.id}`}>
              {item.name}
            </h3>
            {item.description && (
              <p className="text-sm text-muted-foreground mb-2" data-testid={`text-item-description-${item.id}`}>
                {item.description}
              </p>
            )}
            <p className="font-bold text-accent text-lg" data-testid={`text-item-price-${item.id}`}>
              {item.price.toLocaleString()} Ar
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            {localQuantity > 0 && (
              <Button
                variant="outline"
                size="icon"
                onClick={handleDecrement}
                className="h-8 w-8"
                data-testid={`button-decrease-${item.id}`}
              >
                <Minus className="h-4 w-4" />
              </Button>
            )}
            
            {localQuantity > 0 && (
              <span className="w-8 text-center font-semibold" data-testid={`text-quantity-${item.id}`}>
                {localQuantity}
              </span>
            )}
            
            <Button
              variant={localQuantity === 0 ? "default" : "outline"}
              size="icon"
              onClick={handleIncrement}
              className="h-8 w-8"
              data-testid={`button-increase-${item.id}`}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}