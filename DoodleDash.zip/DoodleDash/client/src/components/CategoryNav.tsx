import { Button } from "@/components/ui/button";

interface CategoryNavProps {
  categories: string[];
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function CategoryNav({ categories, activeCategory, onCategoryChange }: CategoryNavProps) {
  const categoryDisplayNames: { [key: string]: string } = {
    "petit-dejeuner": "Petit Déjeuner",
    "plat-riz": "Plat de Riz Malagasy",
    "beignet": "Beignet Malagasy",
    "boisson-chaud": "Boisson Chaud"
  };

  return (
    <nav className="sticky top-[88px] z-40 bg-background border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => onCategoryChange(category)}
              className="whitespace-nowrap flex-shrink-0"
              data-testid={`button-category-${category}`}
            >
              {categoryDisplayNames[category] || category}
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );
}