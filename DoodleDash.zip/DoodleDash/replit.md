# Overview

This is a modern restaurant ordering system for "Hay'nay Tsiro", a Malagasy restaurant specializing in traditional cuisine. The application provides a digital menu interface where customers can browse authentic Malagasy dishes across multiple categories (breakfast, rice dishes, beignets, and hot beverages), add items to their cart, and place orders with payment method selection.

The system features a responsive web interface built with React and TypeScript, backed by a Node.js/Express server with PostgreSQL database integration. The design follows Malagasy cultural aesthetics with a maroon and gold color scheme while maintaining modern UX patterns inspired by food delivery platforms.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component patterns
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Styling**: Tailwind CSS with custom design system based on shadcn/ui components
- **Build Tool**: Vite for fast development and optimized production builds
- **Component Library**: Radix UI primitives with custom styling for accessible UI components

## Backend Architecture
- **Runtime**: Node.js with Express.js web framework
- **Language**: TypeScript with ES modules for type safety and modern JavaScript features
- **API Design**: RESTful endpoints for menu items and order management
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **Development**: Hot reload with Vite middleware integration

## Data Storage Solutions
- **Primary Database**: PostgreSQL for relational data storage
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema versioning
- **Data Modeling**: Two main entities - menu items and orders with JSON-based item storage

## Authentication and Authorization
- **Session-based**: Express sessions with PostgreSQL session store
- **No Authentication Required**: Simple ordering system without user accounts
- **Order Tracking**: UUID-based order identification for customer reference

## Design System and Theming
- **Color Palette**: Malagasy-inspired maroon primary (#800000) with gold accents (#E6C94D)
- **Typography**: Inter font family via Google Fonts CDN
- **Component Variants**: CVA (Class Variance Authority) for consistent component styling
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: Radix UI primitives ensure WCAG compliance

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe database queries and schema management
- **PostgreSQL**: Primary relational database for menu items and orders

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Radix UI**: Headless UI primitives for accessible components
- **Shadcn/UI**: Pre-built component library with Tailwind integration
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Inter font family for typography

## Development and Build Tools
- **Vite**: Fast build tool with HMR and TypeScript support
- **TypeScript**: Static type checking and modern JavaScript features
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

## Frontend Libraries
- **React Query**: Server state management and data fetching
- **React Hook Form**: Form handling with validation
- **Wouter**: Lightweight routing library
- **Date-fns**: Date manipulation utilities
- **Class Variance Authority**: Type-safe CSS class variants

## Backend Dependencies
- **Express.js**: Web framework for Node.js
- **Connect-pg-simple**: PostgreSQL session store for Express
- **Zod**: Runtime type validation for API requests
- **CORS**: Cross-origin resource sharing middleware

## Asset Management
- **Generated Images**: Static assets for hero sections and menu items
- **Replit Integration**: Development environment with runtime error handling