import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const menuItems = pgTable("menu_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // Price in Ariary
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  available: integer("available").default(1), // 1 = available, 0 = unavailable
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  items: text("items").notNull(), // JSON string of order items
  total: integer("total").notNull(), // Total in Ariary
  paymentMethod: text("payment_method").notNull(),
  status: text("status").default("pending"), // pending, confirmed, preparing, ready, delivered
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertMenuItemSchema = createInsertSchema(menuItems).omit({
  id: true,
});

// Schema for server-side order insertion (includes total and status)
export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
}).extend({
  paymentMethod: z.enum(["espèces", "mobile-money"]),
  status: z.enum(["pending", "confirmed", "preparing", "ready", "delivered"])
});

// Schema for status updates
export const orderStatusSchema = z.object({
  status: z.enum(["pending", "confirmed", "preparing", "ready", "delivered"])
});

// Client-side order data
export const clientOrderSchema = z.object({
  customerName: z.string().optional(),
  customerPhone: z.string().optional(),
  items: z.array(z.object({
    menuItemId: z.string(),
    name: z.string(),
    price: z.number(),
    quantity: z.number().int().positive().max(99) // Prevent fractional quantities and set reasonable max
  })),
  paymentMethod: z.enum(["espèces", "mobile-money"])
});

export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
export type MenuItem = typeof menuItems.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
}