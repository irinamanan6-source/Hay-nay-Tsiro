function showCategories() {
  document.getElementById("categories").classList.add("active");
  document.getElementById("menu").classList.add("active");
}

function showCategory(categoryId) {
  document.querySelectorAll(".category").forEach(cat => cat.classList.remove("active"));
  document.getElementById(categoryId).classList.add("active");
}

function updateOrder() {
  let orderList = document.getElementById("order-list");
  orderList.innerHTML = "";
  let total = 0;

  document.querySelectorAll(".item").forEach(item => {
    let input = item.querySelector("input");
    let qty = parseInt(input.value);
    let name = item.childNodes[0].textContent.trim();
    let price = parseInt(item.dataset.price);

    if (qty > 0) {
      let li = document.createElement("li");
      li.textContent = `${qty} x ${name} = ${qty * price} Ar`;
      orderList.appendChild(li);
      total += qty * price;
    }
  });

  document.getElementById("total").textContent = total;
}

function confirmOrder() {
  let total = document.getElementById("total").textContent;
  let payment = document.getElementById("payment-method").value;

  if (total === "0") {
    alert("Votre commande est vide !");
    return;
  }

  if (confirm(`Confirmer la commande de ${total} Ar ?\nPaiement : ${payment}`)) {
    alert("✅ Commande validée !");
  } else {
    alert("❌ Commande annulée.");
  }
}