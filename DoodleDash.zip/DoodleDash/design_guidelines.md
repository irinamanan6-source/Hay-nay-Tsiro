# Design Guidelines for Malagasy Restaurant Ordering System

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern food delivery platforms like Uber Eats and DoorDash, while maintaining the authentic Malagasy cultural identity through the existing maroon and gold color scheme.

## Core Design Elements

### A. Color Palette
**Primary Colors:**
- Brand Maroon: 0 100% 25% (deep burgundy for headers, navigation)
- Accent Gold: 45 75% 60% (warm gold for highlights, buttons, price displays)

**Supporting Colors:**
- Background Light: 0 0% 98% (clean white for content areas)
- Text Primary: 0 0% 15% (charcoal for main text)
- Text Secondary: 0 0% 45% (medium gray for descriptions)
- Success Green: 120 40% 45% (for order confirmations)

### B. Typography
- **Primary Font**: Inter (via Google Fonts CDN)
- **Headers**: Bold weights (600-700) for menu categories and restaurant name
- **Body Text**: Regular (400) and medium (500) weights for menu items and descriptions
- **Prices**: Semibold (600) in gold accent color for emphasis

### C. Layout System
**Tailwind Spacing Units**: Consistent use of 2, 4, 6, and 8 units
- `p-4` for card padding
- `m-6` for section spacing
- `gap-4` for grid layouts
- `h-8` for button heights

### D. Component Library

**Navigation**
- Fixed header with restaurant logo and cart icon
- Maroon background with gold accent highlights
- Sticky category navigation below main header

**Menu Cards**
- Clean white cards with subtle shadows
- Product images with overlay text
- Price prominently displayed in gold
- Add to cart buttons with quantity selectors

**Shopping Cart**
- Slide-out drawer from right side
- Item list with quantity controls and remove options
- Subtotal and total calculations in gold
- Prominent checkout button in maroon

**Order Management**
- Order confirmation modal with order details
- Payment method selection (cash, mobile money)
- Order status tracking with progress indicators

### E. Visual Treatments

**Gradients**
- Subtle maroon-to-darker-maroon gradients for headers
- Light gold gradients for promotional banners
- Soft overlay gradients on food images for text readability

**Background Treatments**
- Clean white backgrounds for content areas
- Subtle warm gray (#fafafa) for section dividers
- Light maroon tints for category sections

## Images
- **Hero Section**: Large banner image featuring traditional Malagasy dishes with maroon overlay
- **Menu Items**: High-quality food photography for each dish
- **Cultural Elements**: Subtle Malagasy patterns or motifs as background textures
- **Restaurant Ambiance**: Optional images of restaurant interior or cooking process

## Key Design Principles
1. **Cultural Authenticity**: Maintain Malagasy identity through color choices and imagery
2. **Food-First Design**: Emphasize appetizing food photography and clear pricing
3. **Intuitive Navigation**: Clear category organization matching traditional Malagasy meal structure
4. **Mobile-Optimized**: Touch-friendly interfaces for mobile ordering
5. **Trust & Clarity**: Clear pricing, order summary, and payment options to build customer confidence

## Animations
Minimal, purposeful animations:
- Smooth cart drawer slide transitions
- Gentle hover effects on menu items
- Loading states for order processing
- Success confirmations with subtle celebrations

This design maintains the authentic Malagasy restaurant character while providing a modern, efficient ordering experience that users expect from contemporary food delivery applications.