import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema, clientOrderSchema, orderStatusSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Menu Items endpoints
  app.get("/api/menu-items", async (req, res) => {
    try {
      const items = await storage.getMenuItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch menu items" });
    }
  });

  app.get("/api/menu-items/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const items = await storage.getMenuItemsByCategory(category);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch menu items" });
    }
  });

  // Orders endpoints
  app.post("/api/orders", async (req, res) => {
    try {
      // Validate client request
      const clientOrder = clientOrderSchema.parse(req.body);
      
      // Validate all menu items exist and are available, build canonical items
      let calculatedTotal = 0;
      const canonicalItems: Array<{
        menuItemId: string;
        name: string;
        price: number;
        quantity: number;
      }> = [];
      
      for (const item of clientOrder.items) {
        const menuItem = await storage.getMenuItem(item.menuItemId);
        if (!menuItem) {
          res.status(400).json({ error: `Menu item ${item.menuItemId} not found` });
          return;
        }
        if (!menuItem.available) {
          res.status(400).json({ error: `Menu item ${menuItem.name} is not available` });
          return;
        }
        // Use canonical data from database
        calculatedTotal += menuItem.price * item.quantity;
        canonicalItems.push({
          menuItemId: menuItem.id,
          name: menuItem.name,
          price: menuItem.price,
          quantity: item.quantity
        });
      }
      
      // Create validated order with canonical data
      const orderData = {
        customerName: clientOrder.customerName,
        customerPhone: clientOrder.customerPhone,
        items: JSON.stringify(canonicalItems), // Use canonical data from server
        total: calculatedTotal, // Use server-computed total
        paymentMethod: clientOrder.paymentMethod,
        status: "pending" as const // Server-controlled status
      };
      
      // Validate the final order data
      const validatedOrderData = insertOrderSchema.parse(orderData);
      
      const order = await storage.createOrder(validatedOrderData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid order data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create order" });
      }
    }
  });

  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const order = await storage.getOrder(id);
      if (!order) {
        res.status(404).json({ error: "Order not found" });
        return;
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate status with enum
      const { status } = orderStatusSchema.parse(req.body);

      const order = await storage.updateOrderStatus(id, status);
      if (!order) {
        res.status(404).json({ error: "Order not found" });
        return;
      }
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid status", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update order status" });
      }
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
