import { type MenuItem, type InsertMenuItem, type Order, type InsertOrder } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Menu Items
  getMenuItems(): Promise<MenuItem[]>;
  getMenuItemsByCategory(category: string): Promise<MenuItem[]>;
  getMenuItem(id: string): Promise<MenuItem | undefined>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
}

// Mock menu data based on the original HTML file
const INITIAL_MENU_ITEMS: MenuItem[] = [
  // Petit Déjeuner
  { id: '1', name: 'Vary amin\'ny anana spéciale', description: 'Riz aux légumes spécialité maison', price: 15000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '2', name: 'Vary amin\'ny anana Boosté', description: 'Riz aux légumes version améliorée', price: 10000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '3', name: 'Vary amin\'ny anana Simple', description: 'Riz aux légumes version classique', price: 5000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '4', name: 'Spécialité mokary', description: 'Gâteau traditionnel malagasy', price: 5000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '5', name: 'Spécialité Mafilotra', description: 'Spécialité locale traditionnelle', price: 5000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '6', name: 'Katsaka au coco', description: 'Maïs au lait de coco', price: 3000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '7', name: 'Mangahazo au coco', description: 'Manioc au lait de coco', price: 3000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '8', name: 'Patate douce au lait', description: 'Patate douce avec lait', price: 3000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  { id: '9', name: 'Katsaka au lait', description: 'Maïs au lait', price: 2000, category: 'petit-dejeuner', imageUrl: null, available: 1 },
  
  // Plat de Riz Malagasy
  { id: '10', name: 'Ravitoto sy henankisoa au coco', description: 'Feuilles de manioc pilées avec porc au coco', price: 30000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '11', name: 'Ovy sy trondro maina Rony', description: 'Pommes de terre avec poisson séché', price: 25000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '12', name: 'Voanjobory sy henankisoa', description: 'Haricots lima avec porc', price: 25000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '13', name: 'Ravim-voatavo sy henan\'omb', description: 'Feuilles de potiron avec bœuf', price: 20000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '14', name: 'Saucisse sy tsaramaso', description: 'Saucisse avec haricots', price: 20000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '15', name: 'Ovy sy patsa rony', description: 'Pommes de terre avec conserve', price: 20000, category: 'plat-riz', imageUrl: null, available: 1 },
  { id: '16', name: 'Ravim-bomanga sy henan\'omb', description: 'Feuilles de patate douce avec bœuf', price: 15000, category: 'plat-riz', imageUrl: null, available: 1 },
  
  // Beignet Malagasy
  { id: '17', name: 'Pakopako sy masikita sauce', description: 'Beignets spéciaux avec sauce', price: 10000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '18', name: 'Assiette de beignet de banane', description: 'Beignets de banane traditionnels', price: 5000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '19', name: 'Koban\'ny talatan\' ny volonondry', description: 'Beignet de laine de mouton', price: 5000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '20', name: 'Assiette de beignet à variété', description: 'Assortiment de beignets', price: 5000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '21', name: 'Godrogodro', description: 'Beignets croustillants traditionnels', price: 3000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '22', name: 'Assiette de beignet croquant', description: 'Beignets croustillants', price: 2000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '23', name: 'Assiette de beignet au manioc', description: 'Beignets de manioc', price: 2000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '24', name: 'Mofo menakely', description: 'Petits pains traditionnels', price: 1000, category: 'beignet', imageUrl: null, available: 1 },
  { id: '25', name: 'Koba akondro', description: 'Gâteau de banane traditionnel', price: 1000, category: 'beignet', imageUrl: null, available: 1 },
  
  // Boisson Chaud
  { id: '26', name: 'Verre de Lait', description: 'Lait frais local', price: 2000, category: 'boisson-chaud', imageUrl: null, available: 1 },
  { id: '27', name: 'Café au lait', description: 'Café local avec lait', price: 2000, category: 'boisson-chaud', imageUrl: null, available: 1 },
  { id: '28', name: 'Chocolat chaud', description: 'Chocolat chaud crémeux', price: 2000, category: 'boisson-chaud', imageUrl: null, available: 1 },
  { id: '29', name: 'Thé au cannel', description: 'Thé à la cannelle', price: 1500, category: 'boisson-chaud', imageUrl: null, available: 1 },
  { id: '30', name: 'Verre de Lait soja', description: 'Lait de soja', price: 1500, category: 'boisson-chaud', imageUrl: null, available: 1 },
  { id: '31', name: 'Café nature', description: 'Café noir traditionnel', price: 1000, category: 'boisson-chaud', imageUrl: null, available: 1 }
];

export class MemStorage implements IStorage {
  private menuItems: Map<string, MenuItem>;
  private orders: Map<string, Order>;

  constructor() {
    this.menuItems = new Map();
    this.orders = new Map();
    
    // Initialize with mock menu items
    INITIAL_MENU_ITEMS.forEach(item => {
      this.menuItems.set(item.id, item);
    });
  }

  // Menu Items
  async getMenuItems(): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values());
  }

  async getMenuItemsByCategory(category: string): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(item => item.category === category);
  }

  async getMenuItem(id: string): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }

  async createMenuItem(insertItem: InsertMenuItem): Promise<MenuItem> {
    const id = randomUUID();
    const item: MenuItem = { ...insertItem, id };
    this.menuItems.set(id, item);
    return item;
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = { ...insertOrder, id, createdAt: new Date() };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (order) {
      order.status = status;
      this.orders.set(id, order);
    }
    return order;
  }
}

export const storage = new MemStorage();
